<form role="search" method="get" class="search-form" action="<?php bloginfo('url'); ?>/">
	<label>
		<div class="fa fa-search" style="content:'';top:30px;right:5px;font-size:35px;z-index:1000;position: absolute;cursor:pointer;">
		</div>
		<input type="search" class="search-field" placeholder="Search Site..." value="" name="s" title="Search">
	</label>
	<input type="submit" class="search-submit" value="Search">
</form>